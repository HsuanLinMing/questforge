// lib/game/tts/tts_playback_controller.dart
import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:questforge_flutter_demo/game/widgets/story_card_v2.dart';
import 'package:questforge_ui_contract/questforge_contract.dart';

typedef LogFn = void Function(String tag, Map<String, Object?> extra);
typedef ScrollToParagraphFn = void Function(int index);

class TtsPlaybackState {
  const TtsPlaybackState({
    required this.ready,
    required this.enabled,
    required this.playing,
    required this.activeParagraphIndex,
    required this.activeChunkIndex,
    required this.viewFp,
    required this.rate,
  });

  final bool ready;
  final bool enabled;
  final bool playing;
  final int activeParagraphIndex;
  final int activeChunkIndex;
  final String viewFp;

  /// ✅ 播放倍速（just_audio speed）
  final double rate;

  TtsPlaybackState copyWith({
    bool? ready,
    bool? enabled,
    bool? playing,
    int? activeParagraphIndex,
    int? activeChunkIndex,
    String? viewFp,
    double? rate,
  }) {
    return TtsPlaybackState(
      ready: ready ?? this.ready,
      enabled: enabled ?? this.enabled,
      playing: playing ?? this.playing,
      activeParagraphIndex: activeParagraphIndex ?? this.activeParagraphIndex,
      activeChunkIndex: activeChunkIndex ?? this.activeChunkIndex,
      viewFp: viewFp ?? this.viewFp,
      rate: rate ?? this.rate,
    );
  }
}

// -----------------------------------------------------------------------------
// Playlist v1 (from python command: type=tts_playlist_v1)
// -----------------------------------------------------------------------------
class _TtsPlaylistItem {
  _TtsPlaylistItem({
    required this.index,
    required this.path,
    required this.role,
    required this.voice,
    required this.text,
    required this.format,
  });

  final int index; // paragraph index
  final String path; // file://...
  final String role;
  final String voice;
  final String text;
  final String format;

  static _TtsPlaylistItem? tryFromMap(Map<String, dynamic> m) {
    final path = '${m['path'] ?? ''}'.trim();
    if (path.isEmpty) return null;

    final idxRaw = m['index'];
    final idx = (idxRaw is int) ? idxRaw : int.tryParse('$idxRaw') ?? 0;

    return _TtsPlaylistItem(
      index: idx,
      path: path,
      role: '${m['role'] ?? ''}',
      voice: '${m['voice'] ?? ''}',
      text: '${m['text'] ?? ''}',
      format: '${m['format'] ?? ''}',
    );
  }
}

class _TtsPlaylistV1 {
  _TtsPlaylistV1({
    required this.scope,
    required this.viewFp,
    required this.status,
    required this.reason,
    required this.items,
  });

  final String scope; // view/end
  final String viewFp;
  final String status; // ok/unavailable/empty_narration/error
  final String reason;
  final List<_TtsPlaylistItem> items;

  bool get playable => status == 'ok' && items.isNotEmpty;

  static _TtsPlaylistV1 fromCommand(Map<String, dynamic> cmd) {
    final itemsRaw = cmd['items'];
    final items = <_TtsPlaylistItem>[];
    if (itemsRaw is List) {
      for (final x in itemsRaw) {
        if (x is Map) {
          final it = _TtsPlaylistItem.tryFromMap(x.cast<String, dynamic>());
          if (it != null) items.add(it);
        }
      }
    }

    return _TtsPlaylistV1(
      scope: '${cmd['scope'] ?? 'view'}',
      viewFp: '${cmd['view_fp'] ?? ''}',
      status: '${cmd['status'] ?? 'ok'}',
      reason: '${cmd['reason'] ?? ''}',
      items: items,
    );
  }
}

///
/// TTS 播放控制器（改為：播放 Python 回來的音檔 playlist）
/// - activeChunkIndex：代表 playlist item cursor（不是文字 chunk）
/// - activeParagraphIndex：代表目前播放到哪一段（用 item.index）
/// - rate：代表音檔播放倍速（不是合成語速）
///
class TtsPlaybackController {
  TtsPlaybackController({
    LogFn? logger,
  }) : _logFn = logger;

  /// narration 播放到「playlist 最後一個 item」才觸發（但必須「本 view 真的播過」）
  VoidCallback? onNarrationEnd;

  // ---------------------------
  // public
  // ---------------------------
  final ValueNotifier<TtsPlaybackState> vn = ValueNotifier<TtsPlaybackState>(
    const TtsPlaybackState(
      ready: false,
      enabled: true,
      playing: false,
      activeParagraphIndex: 0,
      activeChunkIndex: 0,
      viewFp: '',
      rate: 1.0, // ✅ 音檔倍速預設 1.0
    ),
  );

  bool get ready => vn.value.ready;
  bool get enabled => vn.value.enabled;
  bool get playing => vn.value.playing;
  int get activeParagraphIndex => vn.value.activeParagraphIndex;
  double get rate => vn.value.rate;

  void setEnabled(bool on) => vn.value = vn.value.copyWith(enabled: on);

  /// ✅ 外部設定倍速（just_audio speed）
  Future<void> setRate(double r) async {
    final next = r.clamp(0.6, 1.4);
    vn.value = vn.value.copyWith(rate: next);
    try {
      await _player.setSpeed(next);
    } catch (_) {}
  }

  // init once
  Future<void> init() async {
    if (_inited) return;
    _inited = true;

    // speed from state
    try {
      await _player.setSpeed(vn.value.rate);
    } catch (_) {}

    _stateSub?.cancel();
    _stateSub = _player.playerStateStream.listen((st) {
      if (_tokenSession != _playSession) return;
      if (st.processingState == ProcessingState.completed) {
        _triggerAdvance('audio_completed');
      }
    });

    vn.value = vn.value.copyWith(ready: true);
  }

  Future<void> dispose() async {
    _fallbackTimer?.cancel();
    _fallbackTimer = null;

    await _stateSub?.cancel();
    _stateSub = null;

    try {
      await _player.dispose();
    } catch (_) {}

    vn.dispose();
  }

  // ---------------------------------------------------------------------------
  // Integration point from GamePage:
  // - view changed: pass playlist command raw map (tts_playlist_v1)
  // ---------------------------------------------------------------------------
  Future<void> handleViewChanged({
    required NodeView view,
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required bool autoPlay,
    required ScrollToParagraphFn scrollTo,
    required Map<String, dynamic>? playlistCmd,
  }) async {
    _scrollTo = scrollTo;

    _playSession++; // cut callbacks
    await stop(resetToStart: true);

    _playParagraphs = const <StoryParagraph>[];
    _playViewFp = '';
    _playlist = null;

    // ✅ view 切換時：重置「本 view 是否真的播過」
    _didSpeakInThisView = false;
    _didSpeakViewFp = viewFp;

    // Always store paragraphs for bounds/scroll even if no audio
    _playParagraphs = paragraphs;
    _playViewFp = viewFp;

    final pl = (playlistCmd == null) ? null : _TtsPlaylistV1.fromCommand(playlistCmd);
    _playlist = pl;
    _playlistCursor = 0;

    if (!autoPlay) return;
    if (!enabled || !ready) return;
    if (paragraphs.isEmpty) return;

    // De-dupe by playlist view_fp if present, else fallback to viewFp
    final dedupeFp = (pl?.viewFp.trim().isNotEmpty ?? false) ? pl!.viewFp.trim() : viewFp;
    if (_lastAutoPlayedFp == dedupeFp) return;
    _lastAutoPlayedFp = dedupeFp;

    // ✅ 核心修正：playlist 不可播時，不要 onNarrationEnd（避免自動推進到指認）
    if (pl == null || !pl.playable) {
      _log('PLAYLIST_UNAVAILABLE', {
        'status': pl?.status ?? 'missing',
        'reason': pl?.reason ?? '',
      });
      return;
    }

    await Future<void>.delayed(const Duration(milliseconds: 20));
    await playParagraph(
      index: 0,
      paragraphs: paragraphs,
      viewFp: viewFp,
      stopBeforeFirstChunk: true,
      deferUiUntilSpeak: false,
      scrollTo: scrollTo,
    );
  }

  Future<void> togglePlay({
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required ScrollToParagraphFn scrollTo,
  }) async {
    _scrollTo = scrollTo;

    if (!enabled) return;
    if (paragraphs.isEmpty) return;

    final pl = _playlist;
    if (pl == null || !pl.playable) {
      // ✅ 沒音檔就不要 pretend 播完（更不能觸發 onNarrationEnd）
      _log('TOGGLE_NO_AUDIO', {'reason': pl?.status ?? 'missing'});
      return;
    }

    if (playing) {
      await stop(resetToStart: false);
      return;
    }

    final i = activeParagraphIndex.clamp(0, paragraphs.length - 1);
    await playParagraph(
      index: i,
      paragraphs: paragraphs,
      viewFp: viewFp,
      stopBeforeFirstChunk: true,
      deferUiUntilSpeak: false,
      scrollTo: scrollTo,
    );
  }

  Future<void> prev({
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required ScrollToParagraphFn scrollTo,
  }) async {
    await seekTo(
      index: activeParagraphIndex - 1,
      paragraphs: paragraphs,
      viewFp: viewFp,
      scrollTo: scrollTo,
    );
  }

  Future<void> next({
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required ScrollToParagraphFn scrollTo,
  }) async {
    await seekTo(
      index: activeParagraphIndex + 1,
      paragraphs: paragraphs,
      viewFp: viewFp,
      scrollTo: scrollTo,
    );
  }

  /// ✅ 重播目前段落（從段落第一個 item 開始）
  Future<void> replayCurrent({
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required ScrollToParagraphFn scrollTo,
  }) async {
    _scrollTo = scrollTo;

    if (!enabled) return;
    if (paragraphs.isEmpty) return;

    final pl = _playlist;
    if (pl == null || !pl.playable) {
      _log('REPLAY_NO_AUDIO', {'reason': pl?.status ?? 'missing'});
      return;
    }

    final idx = activeParagraphIndex.clamp(0, paragraphs.length - 1);

    _playSession++; // cut callbacks
    await stop(resetToStart: false);

    vn.value = vn.value.copyWith(
      activeParagraphIndex: idx,
      activeChunkIndex: 0,
    );
    scrollTo(idx);

    await playParagraph(
      index: idx,
      paragraphs: paragraphs,
      viewFp: viewFp,
      stopBeforeFirstChunk: true,
      deferUiUntilSpeak: false,
      scrollTo: scrollTo,
    );
  }

  Future<void> seekTo({
    required int index,
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required ScrollToParagraphFn scrollTo,
  }) async {
    _scrollTo = scrollTo;

    if (!enabled) return;
    if (paragraphs.isEmpty) return;

    final pl = _playlist;
    if (pl == null || !pl.playable) {
      // no audio; update highlight/scroll only
      final nextIndex = index.clamp(0, paragraphs.length - 1);
      vn.value = vn.value.copyWith(activeParagraphIndex: nextIndex, activeChunkIndex: 0);
      scrollTo(nextIndex);
      return;
    }

    final nextIndex = index.clamp(0, paragraphs.length - 1);
    final wasPlaying = playing;

    _playSession++; // cut callbacks
    await stop(resetToStart: false);

    vn.value = vn.value.copyWith(
      activeParagraphIndex: nextIndex,
      activeChunkIndex: 0,
    );
    scrollTo(nextIndex);

    if (wasPlaying) {
      await playParagraph(
        index: nextIndex,
        paragraphs: paragraphs,
        viewFp: viewFp,
        stopBeforeFirstChunk: true,
        deferUiUntilSpeak: false,
        scrollTo: scrollTo,
      );
    }
  }

  Future<void> stop({required bool resetToStart}) async {
    _fallbackTimer?.cancel();
    _fallbackTimer = null;

    _handlingAdvance = false;

    _speakToken++;
    _handledToken = -1;

    try {
      await _player.stop();
    } catch (_) {}

    vn.value = vn.value.copyWith(
      playing: false,
      activeChunkIndex: 0,
      activeParagraphIndex: resetToStart ? 0 : vn.value.activeParagraphIndex,
      viewFp: vn.value.viewFp,
    );

    _pendingActiveParagraphIndex = null;
  }

  // ---------------------------
  // internals
  // ---------------------------
  final LogFn? _logFn;

  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<PlayerState>? _stateSub;

  bool _inited = false;

  List<StoryParagraph> _playParagraphs = const <StoryParagraph>[];
  String _playViewFp = '';

  ScrollToParagraphFn? _scrollTo;

  String _lastAutoPlayedFp = '';

  int _playSession = 0;

  int _speakToken = 0;
  int _handledToken = -1;
  int _tokenSession = 0;

  bool _handlingAdvance = false;

  int? _pendingActiveParagraphIndex;

  _TtsPlaylistV1? _playlist;
  int _playlistCursor = 0;

  Timer? _fallbackTimer;

  // ✅ 核心修正：本 view 是否「真的成功播放過」至少一個音檔
  bool _didSpeakInThisView = false;
  String _didSpeakViewFp = '';

  void _log(String tag, Map<String, Object?> extra) {
    _logFn?.call(tag, <String, Object?>{
      'play': vn.value.playing,
      'p': vn.value.activeParagraphIndex,
      'c': vn.value.activeChunkIndex,
      'sess': _playSession,
      'token': _speakToken,
      'handled': _handledToken,
      'viewFp': _playViewFp,
      'rate': vn.value.rate,
      'didSpeak': _didSpeakInThisView,
      'didSpeakFp': _didSpeakViewFp,
      ...extra,
    });
  }

  // fallback timeout (防止某些平台 completed callback 不穩)
  Duration _estimateAudioTimeout(_TtsPlaylistItem item) {
    // 粗估：字數越長給越久（但有上下限）
    final len = item.text.trim().length;
    var ms = 1200 + len * 160;
    if (ms < 1500) ms = 1500;
    if (ms > 18000) ms = 18000;
    return Duration(milliseconds: ms);
  }

  void _armFallbackTimer({required int token, required _TtsPlaylistItem item}) {
    _fallbackTimer?.cancel();
    _fallbackTimer = Timer(_estimateAudioTimeout(item), () {
      if (_tokenSession != _playSession) return;
      if (token != _speakToken) return;
      _triggerAdvance('fallback_timeout');
    });
  }

  void _triggerAdvance(String source) {
    if (!vn.value.playing) return;
    if (_tokenSession != _playSession) return;

    if (_handledToken == _speakToken) return;
    _handledToken = _speakToken;

    _fallbackTimer?.cancel();
    _fallbackTimer = null;

    if (_handlingAdvance) return;
    _handlingAdvance = true;

    _log('ADVANCE', {'by': source});

    Future.microtask(() async {
      try {
        if (_tokenSession != _playSession) return;
        await _advanceAfterItemEnd();
      } finally {
        _handlingAdvance = false;
      }
    });
  }

  int _firstCursorForParagraph(int paragraphIndex) {
    final pl = _playlist;
    if (pl == null) return 0;
    for (var i = 0; i < pl.items.length; i++) {
      if (pl.items[i].index == paragraphIndex) return i;
    }
    // fallback: clamp
    return paragraphIndex.clamp(0, (pl.items.length - 1).clamp(0, 999999));
  }

  Future<void> playParagraph({
    required int index,
    required List<StoryParagraph> paragraphs,
    required String viewFp,
    required bool stopBeforeFirstChunk,
    required bool deferUiUntilSpeak,
    required ScrollToParagraphFn scrollTo,
  }) async {
    if (!ready || !enabled) return;
    if (paragraphs.isEmpty) return;
    if (index < 0 || index >= paragraphs.length) return;

    _scrollTo = scrollTo;

    // playlist must be playable
    final pl = _playlist;
    if (pl == null || !pl.playable) {
      _log('PLAYPARA_NO_AUDIO', {'reason': pl?.status ?? 'missing'});
      return;
    }

    _playParagraphs = paragraphs;
    _playViewFp = viewFp;

    // set cursor to first item of this paragraph
    final cursor = _firstCursorForParagraph(index);
    if (cursor < 0 || cursor >= pl.items.length) return;
    _playlistCursor = cursor;

    vn.value = vn.value.copyWith(
      playing: true,
      viewFp: viewFp,
      activeChunkIndex: 0,
      activeParagraphIndex: deferUiUntilSpeak ? vn.value.activeParagraphIndex : index,
    );

    _pendingActiveParagraphIndex = deferUiUntilSpeak ? index : null;

    if (!deferUiUntilSpeak) {
      scrollTo(index);
    }

    await _playCurrentItem(stopBeforePlay: stopBeforeFirstChunk, scrollTo: scrollTo);
  }

  Future<void> _playCurrentItem({
    required bool stopBeforePlay,
    required ScrollToParagraphFn scrollTo,
  }) async {
    if (!ready || !enabled) return;

    final pl = _playlist;
    if (pl == null || !pl.playable) return;
    if (_playlistCursor < 0 || _playlistCursor >= pl.items.length) return;

    final item = pl.items[_playlistCursor];

    _speakToken++;
    final token = _speakToken;
    _handledToken = -1;
    _tokenSession = _playSession;

    _log('PLAY_ITEM', {
      'stop': stopBeforePlay,
      'cursor': _playlistCursor,
      'pIndex': item.index,
      'path': item.path,
      'role': item.role,
      'voice': item.voice,
    });

    try {
      if (stopBeforePlay) {
        _fallbackTimer?.cancel();
        _fallbackTimer = null;
        await _player.stop();
      }

      final pending = _pendingActiveParagraphIndex;
      if (pending != null) {
        vn.value = vn.value.copyWith(activeParagraphIndex: pending);
        scrollTo(pending);
        _pendingActiveParagraphIndex = null;
      } else {
        // normal: update active paragraph to item index
        if (vn.value.activeParagraphIndex != item.index) {
          vn.value = vn.value.copyWith(activeParagraphIndex: item.index);
          scrollTo(item.index);
        }
      }

      // reset chunk index to 0 for each paragraph start, else increment-like cursor
      vn.value = vn.value.copyWith(activeChunkIndex: 0);

      _armFallbackTimer(token: token, item: item);

      final uri = Uri.tryParse(item.path);
      if (uri == null) {
        _triggerAdvance('bad_uri');
        return;
      }

      await _player.setUrl(uri.toString());

      // ✅ 核心修正：只有「真的成功開始播放」才視為 didSpeak
      await _player.play();
      _didSpeakInThisView = true;
      _didSpeakViewFp = vn.value.viewFp;
    } catch (e) {
      _log('AUDIO_ERROR', {'err': e.toString()});
      _triggerAdvance('audio_error');
    }
  }

  Future<void> _advanceAfterItemEnd() async {
    if (!vn.value.playing) return;

    final pl = _playlist;
    if (pl == null || !pl.playable) {
      // ✅ 不可播就停掉，但不要 onNarrationEnd（避免自動推進）
      await stop(resetToStart: false);
      _log('ADVANCE_STOP_NO_AUDIO', {'reason': pl?.status ?? 'missing'});
      return;
    }

    final nextCursor = _playlistCursor + 1;
    if (nextCursor < pl.items.length) {
      _playlistCursor = nextCursor;

      // update "chunk index" as cursor progress inside a paragraph (optional)
      vn.value = vn.value.copyWith(activeChunkIndex: vn.value.activeChunkIndex + 1);

      final scroll = _scrollTo ?? (_) {};
      await _playCurrentItem(stopBeforePlay: false, scrollTo: scroll);
      return;
    }

    // playlist finished
    final endSession = _playSession;
    final endViewFp = vn.value.viewFp;

    await stop(resetToStart: false);

    // ✅ 核心修正：只有「本 view 真的播過」才觸發 onNarrationEnd
    final canFireEnd = endSession == _playSession && _didSpeakInThisView && _didSpeakViewFp == endViewFp;

    _log('PLAYLIST_FINISHED', {
      'canFireEnd': canFireEnd,
      'endViewFp': endViewFp,
    });

    if (canFireEnd) {
      onNarrationEnd?.call();
    }
  }
}
